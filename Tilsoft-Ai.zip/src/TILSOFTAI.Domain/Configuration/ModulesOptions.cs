namespace TILSOFTAI.Domain.Configuration;

public sealed class ModulesOptions
{
    public string[] Enabled { get; set; } = Array.Empty<string>();
}
