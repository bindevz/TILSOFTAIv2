-- DEMO ONLY - do not deploy.
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

PRINT 'DEMO ONLY: demo model views are not deployed by default.';
GO
