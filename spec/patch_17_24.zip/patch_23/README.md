# Patch 23 (EN) - Run Notes

Run ONE yaml at a time in apply_order.
After each yaml: build + test + update spec/PROGRESS.md.

Key acceptance: 413 envelope must be consistent, options must not be rebound, tests must be real.
